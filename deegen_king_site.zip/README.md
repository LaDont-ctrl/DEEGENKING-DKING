# DEEEGEN KING Landing Page
This folder contains the Netlify-ready landing page for **DEEEGEN KING ($DKING)**.

## Files
- `index.html` - Main landing page (Tailwind CDN used)
- `assets/logo.jpg` - Provided logo image

## Deploy
Drag & drop the entire folder at https://app.netlify.com/drop or push to GitHub and use GitHub Pages / Vercel.
